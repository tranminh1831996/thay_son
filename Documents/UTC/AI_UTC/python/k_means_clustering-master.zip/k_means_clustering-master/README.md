# k_means_clustering
This is the code for "K-Means Clustering - The Math of Intelligence (Week 3)" By SIraj Raval on Youtube

## Overview 

This is the code for [this](https://youtu.be/9991JlKnFmk) video on Youtube by Siraj Raval as part of The Math of Intelligence course. 

## Dependencies

* numpy 
* matplotlib

Install missing dependencies using [pip](https://pip.pypa.io/en/stable/).

## Usage

Just run `jupyter notebook` in terminal and you can visit the notebook in your web browser.

Install `jupyter` from [here](http://jupyter.readthedocs.io/en/latest/install.html)

## Credits

The credits for a big part of the code go to [gleydson](https://github.com/gleydson404). I've merely created a wrapper to get people started. 
